package com.lut.beans;

public class NewsRealese {


    private String newsId;
    private String head;
    private String content;
    private String publish_time;
    private String issueuser;
    private String newstype;

    public String getNewsId() {
        return newsId;
    }

    public void setNewsId(String newsId) {
        this.newsId = newsId;
    }

    public String getHead() {
        return head;
    }

    public void setHead(String head) {
        this.head = head;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getPublish_time() {
        return publish_time;
    }

    public void setPublish_time(String publish_time) {
        this.publish_time = publish_time;
    }

    public String getIssueuser() {
        return issueuser;
    }

    public void setIssueuser(String issueuser) {
        this.issueuser = issueuser;
    }

    public String getNewstype() {
        return newstype;
    }

    public void setNewstype(String newstype) {
        this.newstype = newstype;
    }
}
